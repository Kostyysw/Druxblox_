// Конфиг Firebase
const firebaseConfig = {
  apiKey: "AIzaSyA6UE15NYEYUw0hsL9LY2W7QGi2OY0vgWo",
  authDomain: "druxblox-8d353.firebaseapp.com",
  projectId: "druxblox-8d353",
  storageBucket: "druxblox-8d353.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "Druxblox"
};

// Инициализация Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);
const db = getFirestore(app);

// Обработка нажатия кнопки
document.getElementById("posts").addEventListener("click", async () => {
  const file = document.getElementById("files").files[0];
  const text = document.getElementById("posts").value;
  
  if (!file || !text) {
    alert("Выберите файл и введите текст.");
    return;
  }
  
  try {
    const storageRef = ref(storage, 'uploads/' + file.name);
    await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(storageRef);
    
    await addDoc(collection(db, "posts"), {
      text: text,
      fileURL: downloadURL,
      createdAt: new Date()
    });
    
    alert("Пост успешно добавлен!");
  } catch (error) {
    alert("Ошибка: " + error.message);
  }
});



{
  text: "текст поста",
  fileURL: "ссылка на файл",
  likes: 0,
  createdAt: timestamp
}